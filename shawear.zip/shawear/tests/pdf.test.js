import assert from 'node:assert/strict';
import { buildPdf } from '../src/pdf.js';

let passed = 0;
const test = (name, fn) => { fn(); passed += 1; console.log(`  ok  ${name}`); };

const jpeg = (n) => new Uint8Array([0xff, 0xd8, ...Array.from({ length: n }, (_, i) => i % 251), 0xff, 0xd9]);

test('PDF has a valid header, trailer and one A4 page per image', () => {
  const pdf = buildPdf([{ bytes: jpeg(500), width: 1588, height: 2246 }, { bytes: jpeg(300), width: 1588, height: 2246 }]);
  const s = Buffer.from(pdf).toString('latin1');
  assert.ok(s.startsWith('%PDF-1.4'));
  assert.ok(s.trimEnd().endsWith('%%EOF'));
  assert.match(s, /\/Count 2/);
  assert.equal((s.match(/\/Type \/Page /g) || []).length, 2);
  assert.match(s, /\/MediaBox \[0 0 595\.28 841\.89\]/);
  assert.match(s, /\/Filter \/DCTDecode/);
});

test('cross-reference table points at every object', () => {
  const pdf = buildPdf([{ bytes: jpeg(1234), width: 10, height: 20 }, { bytes: jpeg(77), width: 10, height: 20 }, { bytes: jpeg(9), width: 10, height: 20 }]);
  const s = Buffer.from(pdf).toString('latin1');
  const xrefAt = Number(s.match(/startxref\n(\d+)\n/)[1]);
  assert.ok(s.slice(xrefAt).startsWith('xref\n'));
  const lines = s.slice(xrefAt).split('\n');
  const [, total] = lines[1].split(' ').map(Number);
  assert.equal(total, 3 + 3 * 3);
  for (let n = 1; n < total; n++) {
    const entry = lines[2 + n];
    assert.equal(entry.length, 19 + 0, 'entry is 20 bytes with its newline');
    const off = Number(entry.slice(0, 10));
    assert.ok(s.slice(off).startsWith(`${n} 0 obj`), `object ${n} not at offset ${off}`);
  }
});

test('image bytes are embedded unchanged and /Length matches', () => {
  const bytes = jpeg(4000);
  const s = Buffer.from(buildPdf([{ bytes, width: 5, height: 5 }])).toString('latin1');
  assert.match(s, new RegExp(`/Length ${bytes.length} >>`));
  assert.ok(s.includes(Buffer.from(bytes).toString('latin1')));
});

test('refuses to build an empty PDF', () => {
  assert.throws(() => buildPdf([]), /Nothing/);
});

console.log(`pdf: ${passed} passed`);
