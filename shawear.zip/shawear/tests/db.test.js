import 'fake-indexeddb/auto';
import assert from 'node:assert/strict';
import * as db from '../src/db.js';
import { calcInvoice } from '../src/billing.js';

let passed = 0;
const test = async (name, fn) => { await fn(); passed += 1; console.log(`  ok  ${name}`); };

await test('defaults are returned before anything is saved', async () => {
  const s = await db.getSettings();
  assert.equal(s.invoicePrefix, 'INV');
  assert.equal(s.configured, false);
});

await test('demo data loads', async () => {
  const r = await db.seedDemo();
  assert.ok(r.items >= 10);
  assert.equal((await db.all('items')).length, r.items);
});

await test('older saved settings lose their GST fields', async () => {
  await db.put('meta', { key: 'settings', shopName: 'Old Shop', gstin: '27ABCDE1234F1Z5', state: '27', taxInclusive: true, configured: true });
  const s = await db.getSettings();
  assert.equal(s.shopName, 'Old Shop');
  assert.deepEqual(['gstin', 'state', 'taxInclusive'].filter((k) => k in s), []);
  await db.remove('meta', 'settings');
});

const items = await db.all('items');
const cement = items.find((i) => i.code === 'CEM-50');
const nails = items.find((i) => i.code === 'NAIL-2');
const parties = await db.all('parties');
const ramesh = parties.find((p) => p.name.startsWith('Ramesh'));
const supplier = parties.find((p) => p.type === 'supplier');

const makeDraft = (lines, extra = {}) => {
  const calc = calcInvoice(lines);
  return { date: db.todayISO(), partyName: 'Walk-in Customer', lines: calc.lines, total: calc.total, paid: calc.total, ...extra };
};

let inv1;
await test('saving an invoice numbers it and reduces stock', async () => {
  inv1 = await db.saveInvoice(makeDraft([
    { itemId: cement.id, name: 'Cement', unit: 'bag', factor: 1, qty: 10, rate: 390, discPct: 0 },
  ]));
  assert.equal(inv1.no, 'INV-0001');
  assert.equal((await db.get('items', cement.id)).stock, 110);
});

await test('alt units convert to base units (2 boxes of 5kg = 10kg)', async () => {
  await db.saveInvoice(makeDraft([
    { itemId: nails.id, name: 'Nails', unit: 'box', factor: 5, qty: 2, rate: 475, discPct: 0 },
  ]));
  assert.equal((await db.get('items', nails.id)).stock, 50);
});

await test('invoice numbers keep counting up', async () => {
  const inv = await db.saveInvoice(makeDraft([
    { itemId: cement.id, name: 'Cement', unit: 'bag', factor: 1, qty: 1, rate: 390 },
  ]));
  assert.equal(inv.no, 'INV-0003');
});

await test('credit sale without a customer is refused and changes nothing', async () => {
  const before = (await db.get('items', cement.id)).stock;
  await assert.rejects(() => db.saveInvoice(makeDraft([
    { itemId: cement.id, name: 'Cement', unit: 'bag', factor: 1, qty: 5, rate: 390 },
  ], { paid: 0 })), /customer/i);
  assert.equal((await db.get('items', cement.id)).stock, before);
  assert.equal((await db.all('invoices')).length, 3);
});

let credit;
await test('part payment adds the unpaid amount to the customer balance', async () => {
  const startBal = (await db.get('parties', ramesh.id)).balance;
  const draft = makeDraft([
    { itemId: cement.id, name: 'Cement', unit: 'bag', factor: 1, qty: 10, rate: 390 },
  ], { partyId: ramesh.id, partyName: ramesh.name });
  draft.paid = 1000;
  credit = await db.saveInvoice(draft);
  assert.equal(credit.due, draft.total - 1000);
  assert.equal((await db.get('parties', ramesh.id)).balance, startBal + draft.total - 1000);
});

await test('receiving a payment reduces the balance', async () => {
  const before = (await db.get('parties', ramesh.id)).balance;
  await db.recordPayment({ partyId: ramesh.id, amount: 2000, mode: 'upi' });
  assert.equal((await db.get('parties', ramesh.id)).balance, before - 2000);
  await assert.rejects(() => db.recordPayment({ partyId: ramesh.id, amount: 0 }), /valid amount/);
});

await test('cancelling restores stock and balance, and cannot be repeated', async () => {
  const stockBefore = (await db.get('items', cement.id)).stock;
  const balBefore = (await db.get('parties', ramesh.id)).balance;
  await db.cancelInvoice(credit.id);
  assert.equal((await db.get('items', cement.id)).stock, stockBefore + 10);
  assert.equal((await db.get('parties', ramesh.id)).balance, balBefore - credit.due);
  assert.equal((await db.get('invoices', credit.id)).status, 'cancelled');
  await assert.rejects(() => db.cancelInvoice(credit.id), /already cancelled/);
});

await test('stock in converts units and can be put on a supplier account', async () => {
  const before = (await db.get('items', nails.id)).stock;
  await db.addStock({ itemId: nails.id, qty: 4, factor: 5, cost: 360, partyId: supplier.id, billAmount: 1440, paid: 440 });
  const it = await db.get('items', nails.id);
  assert.equal(it.stock, before + 20);
  assert.equal(it.cost, 72);
  assert.equal((await db.get('parties', supplier.id)).balance, -1000);
});

await test('backup can be exported, wiped and restored', async () => {
  const backup = await db.exportAll();
  const invoiceCount = backup.invoices.length;
  await db.wipeAll();
  assert.equal((await db.all('items')).length, 0);
  await db.importAll(JSON.parse(JSON.stringify(backup)));
  assert.equal((await db.all('invoices')).length, invoiceCount);
  const next = await db.saveInvoice(makeDraft([
    { itemId: cement.id, name: 'Cement', unit: 'bag', factor: 1, qty: 1, rate: 390 },
  ]));
  assert.equal(next.no, 'INV-0005'); // counter survived the restore
  await assert.rejects(() => db.importAll({ hello: 'world' }), /not a Shawear backup/);
});

console.log(`db: ${passed} passed`);
