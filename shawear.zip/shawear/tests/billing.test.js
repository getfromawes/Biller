import assert from 'node:assert/strict';
import { calcLine, calcInvoice, rupeesInWords, fmt, qtyFmt } from '../src/billing.js';

let passed = 0;
const test = (name, fn) => { fn(); passed += 1; console.log(`  ok  ${name}`); };

test('line amount is quantity x rate', () => {
  assert.equal(calcLine({ qty: 2, rate: 100 }).total, 200);
  assert.equal(calcLine({ qty: 2.5, rate: 40 }).total, 100);
});

test('discount comes off the line amount', () => {
  assert.equal(calcLine({ qty: 10, rate: 50, discPct: 10 }).total, 450);
});

test('nothing is added on top of the price', () => {
  const l = calcLine({ qty: 3, rate: 333.33 });
  assert.equal(l.total, 999.99);
  assert.deepEqual(Object.keys(l).filter((k) => /tax|gst|hsn/i.test(k)), []);
});

test('missing numbers count as zero', () => {
  assert.equal(calcLine({}).total, 0);
  assert.equal(calcLine({ qty: 'x', rate: 10 }).total, 0);
});

test('invoice total is rounded to the rupee with a round-off line', () => {
  const inv = calcInvoice([{ qty: 1, rate: 100.2 }]);
  assert.equal(inv.subtotal, 100.2);
  assert.equal(inv.total, 100);
  assert.equal(inv.roundOff, -0.2);
});

test('invoice sums multiple lines', () => {
  const inv = calcInvoice([{ qty: 2, rate: 100 }, { qty: 1, rate: 200.6, discPct: 0 }]);
  assert.equal(inv.subtotal, 400.6);
  assert.equal(inv.total, 401);
  assert.equal(inv.roundOff, 0.4);
  assert.equal(inv.lines.length, 2);
});

test('whole-rupee bills have no round off', () => {
  const inv = calcInvoice([{ qty: 10, rate: 390 }]);
  assert.equal(inv.total, 3900);
  assert.equal(inv.roundOff, 0);
});

test('rupees in words uses the Indian system', () => {
  assert.equal(rupeesInWords(1234567.5), 'Twelve Lakh Thirty Four Thousand Five Hundred Sixty Seven Rupees and Fifty Paise Only');
  assert.equal(rupeesInWords(0), 'Zero Rupees Only');
  assert.equal(rupeesInWords(100), 'One Hundred Rupees Only');
  assert.equal(rupeesInWords(25000000), 'Two Crore Fifty Lakh Rupees Only');
  assert.equal(rupeesInWords(0.5), 'Fifty Paise Only');
});

test('money and quantities format the Indian way', () => {
  assert.equal(fmt(1234567.5), '12,34,567.50');
  assert.equal(fmt(0), '0.00');
  assert.equal(qtyFmt(10.7), '10.7');
  assert.equal(qtyFmt(3), '3');
});

console.log(`billing: ${passed} passed`);
