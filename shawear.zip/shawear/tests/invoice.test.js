import assert from 'node:assert/strict';
import { buildModel, layoutInvoice, PAGE } from '../src/invoice-view.js';
import { calcInvoice } from '../src/billing.js';

let passed = 0;
const test = (name, fn) => { fn(); passed += 1; console.log(`  ok  ${name}`); };

// Rough text width: good enough to exercise wrapping and pagination without a canvas.
const measure = (s, font) => s.length * parseFloat(font.match(/(\d+(?:\.\d+)?)px/)[1]) * 0.55;

const settings = { shopName: 'Shawear Test Hardware', address: '12 Market Road, Pune', phone: '9876543210', terms: 'Goods once sold will not be taken back.' };

const L = (n, extra = {}) => ({ itemId: `i${n}`, name: `Item ${n}`, unit: 'pcs', factor: 1, qty: 2, rate: 100, discPct: 0, ...extra });

const makeInv = (lines, extra = {}) => {
  const calc = calcInvoice(lines);
  return {
    no: 'INV-0001', date: '2026-10-20', partyName: 'Ramesh Contractors', partyAddress: 'Plot 4, Pune', partyPhone: '9876500001',
    payMode: 'cash', status: 'active', ...calc, paid: calc.total, due: 0, ...extra,
  };
};

const render = (inv) => layoutInvoice(buildModel(inv, settings), measure);
const textsOf = (cmds) => cmds.filter((c) => c.k === 'text').map((c) => c.s);
const allTexts = (pages) => pages.flatMap(textsOf);
const TAX_WORDS = /GST|HSN|Taxable|Place of supply|TAX INVOICE/i;

test('bill shows items, amounts and total, and nothing about GST', () => {
  const pages = render(makeInv([L(1), L(2, { rate: 250 })]));
  const t = allTexts(pages);
  assert.equal(pages.length, 1);
  assert.ok(t.includes('INVOICE'));
  assert.ok(t.includes('Item 1') && t.includes('Item 2'));
  assert.ok(t.includes('700.00'), 'line amounts add up to 700');
  assert.ok(t.includes('₹700.00'));
  assert.ok(t.includes('Seven Hundred Rupees Only'));
  assert.deepEqual(t.filter((s) => TAX_WORDS.test(s)), []);
  assert.deepEqual(t.filter((s) => /CGST|SGST|IGST/.test(s)), []);
});

test('table columns are # Item Qty Rate Disc % Amount only', () => {
  const heads = buildModel(makeInv([L(1)]), settings).columns.map((c) => c.head);
  assert.deepEqual(heads, ['#', 'Item', 'Qty', 'Rate', 'Disc %', 'Amount']);
});

test('older bills that were saved with GST still draw without any GST', () => {
  const old = makeInv([L(1)]);
  old.lines = old.lines.map((l) => ({ ...l, hsn: '7317', gstRate: 18, taxable: 200, cgst: 18, sgst: 18, igst: 0, total: 236 }));
  Object.assign(old, { taxable: 200, cgst: 18, sgst: 18, igst: 0, total: 236, paid: 236, partyGstin: '27ABCDE1234F1Z5', placeOfSupply: '27', interstate: false });
  const t = allTexts(render(old));
  assert.ok(t.includes('236.00') && t.includes('₹236.00'), 'their saved amounts are kept');
  assert.deepEqual(t.filter((s) => TAX_WORDS.test(s) || /CGST|SGST|IGST/.test(s)), []);
});

test('customer name is drawn in bold', () => {
  const cmds = render(makeInv([L(1)]))[0];
  const name = cmds.find((c) => c.k === 'text' && c.s === 'Ramesh Contractors');
  assert.ok(name, 'customer name missing');
  assert.ok(name.font.startsWith('700 '), `expected bold, got ${name.font}`);
  const walkin = render(makeInv([L(1)], { partyName: 'Walk-in Customer' }))[0].find((c) => c.s === 'Walk-in Customer');
  assert.ok(walkin.font.startsWith('700 '));
});

test('round off shows only when there is one', () => {
  const none = allTexts(render(makeInv([L(1)])));
  assert.ok(!none.includes('Round off') && !none.includes('Sub total'));
  const some = allTexts(render(makeInv([L(1, { rate: 100.4 })])));
  assert.ok(some.includes('Round off') && some.includes('Sub total'));
});

test('every page is the same fixed portrait size and nothing is drawn outside it', () => {
  const pages = render(makeInv(Array.from({ length: 70 }, (_, i) => L(i + 1))));
  assert.ok(pages.length > 1);
  assert.ok(PAGE.h > PAGE.w, 'portrait');
  assert.ok(Math.abs(PAGE.w / PAGE.h - 210 / 297) < 0.001, 'A4 proportions');
  for (const cmds of pages) {
    for (const c of cmds) {
      if (c.k === 'text') assert.ok(c.x >= 0 && c.x <= PAGE.w && c.y >= 0 && c.y <= PAGE.h, `text out of page: ${c.s}`);
      if (c.k === 'line') assert.ok(c.y1 >= 0 && c.y2 <= PAGE.h && c.x1 >= 0 && c.x2 <= PAGE.w);
    }
  }
});

test('a long bill continues on more pages and the totals appear once, at the end', () => {
  const pages = render(makeInv(Array.from({ length: 70 }, (_, i) => L(i + 1))));
  const n = pages.length;
  pages.forEach((cmds, i) => {
    const t = textsOf(cmds);
    assert.ok(t.includes(`Page ${i + 1} of ${n}`));
    assert.equal(t.includes('Amount in words'), i === n - 1);
    assert.equal(t.includes('Authorised signatory'), i === n - 1);
  });
  assert.equal(allTexts(pages).filter((s) => /^Item \d+$/.test(s)).length, 70);
  assert.equal(allTexts(pages).filter((s) => s === 'Total').length, 1);
});

test('a short bill is a single page with no page number', () => {
  const pages = render(makeInv([L(1)]));
  assert.equal(pages.length, 1);
  assert.ok(!allTexts(pages).some((s) => s.startsWith('Page ')));
});

test('long item names wrap instead of running into the next column', () => {
  const longName = 'Heavy duty stainless steel hex head bolt with nut and washer M12 x 150 mm zinc plated pack of fifty pieces';
  const cmds = render(makeInv([L(1, { name: longName })]))[0];
  const parts = cmds.filter((c) => c.k === 'text' && longName.includes(c.s) && c.s.length > 3);
  assert.ok(parts.length >= 2, 'name should wrap onto several lines');
  assert.equal(parts.map((p) => p.s).join(' '), longName);
});

test('balance due and cancelled stamp show when they apply', () => {
  const inv = makeInv([L(1)], { paid: 100, due: 100, status: 'cancelled' });
  const cmds = render(inv)[0];
  assert.ok(textsOf(cmds).includes('Balance due'));
  assert.ok(cmds.some((c) => c.k === 'stamp' && c.text === 'CANCELLED'));
  assert.ok(!textsOf(render(makeInv([L(1)]))[0]).includes('Balance due'));
});

console.log(`invoice layout: ${passed} passed`);
