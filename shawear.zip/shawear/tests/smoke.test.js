// Drives the real UI code in jsdom against an in-memory IndexedDB:
// load demo data, search items, make a credit bill, view/print it, check the ledger, cancel it.
import 'fake-indexeddb/auto';
import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';
import { JSDOM } from 'jsdom';

const html = readFileSync(new URL('../index.html', import.meta.url), 'utf8').replace(/<script[^>]*><\/script>/g, '');
const dom = new JSDOM(html, { url: 'http://localhost/', pretendToBeVisual: true });
const { window } = dom;
window.scrollTo = () => {};
Object.assign(globalThis, {
  window, document: window.document, location: window.location, FormData: window.FormData,
  confirm: () => true,
});

// jsdom cannot draw. Give it a recording 2d context so we can see exactly what the bill draws.
const drawn = []; // every fillText: { s, font }
const fakeCtx = new Proxy({
  font: '',
  measureText(str) { return { width: String(str).length * 7 }; },
  fillText(str) { drawn.push({ s: String(str), font: this.font }); },
}, { get: (t, k) => (k in t ? t[k] : () => {}), set: (t, k, v) => { t[k] = v; return true; } });
window.HTMLCanvasElement.prototype.getContext = () => fakeCtx;
window.HTMLCanvasElement.prototype.toBlob = function toBlob(cb, type) { cb(new Blob([`fake ${this.width}x${this.height}`], { type })); };
const drawnText = () => drawn.map((d) => d.s).join('\n');

const db = await import('../src/db.js');
const { route } = await import('../src/app.js');

const tick = (ms = 40) => new Promise((r) => setTimeout(r, ms));
const $ = (s) => window.document.querySelector(s);
const $$ = (s) => [...window.document.querySelectorAll(s)];
const text = () => $('#app').textContent;
const fire = (el, type, init = {}) => el.dispatchEvent(new window.Event(type, { bubbles: true, cancelable: true, ...init }));
const key = (el, k) => el.dispatchEvent(new window.KeyboardEvent('keydown', { key: k, bubbles: true, cancelable: true }));
const go = async (hash) => {
  if (window.location.hash === hash) await route();
  else { window.location.hash = hash; await tick(100); }
};

let passed = 0;
const test = async (name, fn) => { await fn(); passed += 1; console.log(`  ok  ${name}`); };

await tick(100); // let the initial render finish

await test('home screen of a new shop shows only Add party and Add bill', async () => {
  assert.deepEqual($$('#app button, #app a').map((e) => e.textContent.trim()), ['Add party', 'Add bill']);
  assert.doesNotMatch(text(), /Sales today|To collect|Low stock|Recent bills|New bill|My Hardware Store|sample/i);
  await db.seedDemo();
  assert.ok((await db.all('items')).length >= 10);
});

await test('home screen of a new shop has Add party and Add bill buttons that work', async () => {
  await go('#/');
  assert.ok($('#start-party'), 'Add party button missing');
  assert.ok($('#start-bill'), 'Add bill button missing');
  assert.equal($('#start-party').textContent, 'Add party');
  assert.equal($('#start-bill').textContent, 'Add bill');

  $('#start-bill').click();
  await tick(100);
  assert.equal(window.location.hash, '#/billing');
  assert.ok($('#isearch'), 'New bill screen did not open');

  await go('#/');
  $('#start-party').click();
  const f = $('#modal #f');
  assert.ok(f, 'party form did not open');
  f.querySelector('[name=name]').value = 'Gupta Traders';
  fire(f, 'submit');
  await tick(150);
  const saved = (await db.all('parties')).find((p) => p.name === 'Gupta Traders');
  assert.ok(saved, 'party was not saved');
  assert.equal(saved.type, 'customer');
  assert.ok($('#start-party'), 'buttons stay until the first bill is made');
});

await test('menu is a bottom bar of icon buttons and highlights the open screen', async () => {
  const links = $$('#nav a');
  assert.deepEqual(links.map((a) => a.textContent.trim()), ['Dashboard', 'New bill', 'Invoices', 'Items', 'Parties', 'Settings']);
  assert.ok(links.every((a) => a.querySelector('svg')), 'every menu button has an icon');
  assert.equal($('header #nav'), null, 'menu is no longer in the top bar');
  assert.ok($('#nav').classList.contains('tabbar'));
  await go('#/items');
  assert.equal($('#nav a.active').textContent.trim(), 'Items');
  assert.equal($('#nav a.active').getAttribute('aria-current'), 'page');
  assert.equal($$('#nav a[aria-current]').length, 1);
  await go('#/');
  assert.equal($('#nav a.active').textContent.trim(), 'Dashboard');
});

await test('items screen lists items and filters by search', async () => {
  await go('#/items');
  const all = $$('#rows tr').length;
  assert.ok(all >= 10);
  assert.doesNotMatch($('#app').textContent, /GST|HSN/i);
  $('#q').value = 'cement';
  fire($('#q'), 'input');
  assert.equal($$('#rows tr').length, 1);
  $('#q').value = 'zzzz';
  fire($('#q'), 'input');
  assert.match($('#rows').textContent, /No item matches/);
});

await test('adding an item through the form saves it', async () => {
  await go('#/items');
  $('#add').click();
  const f = $('#modal #f');
  assert.ok(f, 'item form did not open');
  assert.equal(f.querySelector('[name=hsn]'), null);
  assert.equal(f.querySelector('[name=gstRate]'), null);
  assert.doesNotMatch(f.textContent, /GST|HSN/i);
  f.querySelector('[name=name]').value = 'Hex Bolt M10';
  f.querySelector('[name=p_retail]').value = '12';
  f.querySelector('[name=stock]').value = '300';
  fire(f, 'submit');
  await tick(150);
  const saved = (await db.all('items')).find((i) => i.name === 'Hex Bolt M10');
  assert.ok(saved);
  assert.equal(saved.prices.retail, 12);
  assert.equal(saved.unit, 'pcs');
  assert.deepEqual(Object.keys(saved).filter((k) => /gst|hsn|tax/i.test(k)), []);
});

await test('stock-in form adds stock', async () => {
  await go('#/items');
  const bolt = (await db.all('items')).find((i) => i.name === 'Hex Bolt M10');
  const row = $$('#rows tr').find((tr) => tr.dataset.id === bolt.id);
  row.querySelector('[data-act=stock]').click();
  await tick(150);
  const f = $('#modal #f');
  f.querySelector('[name=qty]').value = '50';
  fire(f, 'submit');
  await tick(150);
  assert.equal((await db.get('items', bolt.id)).stock, 350);
});

const cement = (await db.all('items')).find((i) => i.code === 'CEM-50');
const ramesh = (await db.all('parties')).find((p) => p.name.startsWith('Ramesh'));
const openingBalance = ramesh.balance;

await test('billing: search, Enter adds the item, quantity edits update the total', async () => {
  await go('#/billing');
  const s = $('#isearch');
  s.value = 'cement';
  fire(s, 'input');
  assert.ok($$('#results .result').length >= 1);
  key(s, 'Enter');
  assert.equal($$('#cartrows tr[data-i]').length, 1);
  const qty = $('#cartrows [data-f=qty]');
  qty.value = '10';
  fire(qty, 'input');
  // 10 x 390 = 3,900, nothing added on top
  assert.match($('#totals').textContent, /3,900\.00/);
  assert.doesNotMatch($('#totals').textContent, /GST|Taxable/);
  assert.equal($('#paid').value, '3900');
});

await test('billing: credit sale to a walk-in is refused', async () => {
  $('#mode').value = 'credit';
  fire($('#mode'), 'change');
  $('#save').click();
  await tick(100);
  assert.match($('#toast').textContent, /Choose a customer/);
  assert.equal((await db.all('invoices')).length, 0);
});

await test('billing: credit sale to a customer saves, adjusts stock and balance, opens the invoice', async () => {
  $('#party').value = ramesh.id;
  fire($('#party'), 'change');
  $('#paid').value = '1000';
  fire($('#paid'), 'input');
  assert.match($('#due').textContent, /2,900\.00/);
  $('#save').click();
  await tick(200);
  assert.match(window.location.hash, /^#\/invoice\//);
  const [inv] = await db.all('invoices');
  assert.equal(inv.no, 'INV-0001');
  assert.equal(inv.total, 3900);
  assert.equal(inv.due, 2900);
  assert.equal((await db.get('items', cement.id)).stock, 110);
  assert.equal((await db.get('parties', ramesh.id)).balance, openingBalance + 2900);
});

await test('invoice screen draws one fixed A4 portrait page, with the customer name in bold', async () => {
  const canvases = $$('#sheet canvas.bill-page');
  assert.equal(canvases.length, 1);
  assert.equal(canvases[0].width, 1588);
  assert.equal(canvases[0].height, 2246); // 210 x 297 mm
  const t = drawnText();
  assert.match(t, /^INVOICE$/m);
  assert.match(t, /Invoice no: INV-0001/);
  assert.match(t, /Three Thousand Nine Hundred Rupees Only/);
  assert.doesNotMatch(t, /GST|HSN|Taxable|Place of supply|TAX INVOICE/);
  const name = drawn.find((d) => d.s === 'Ramesh Contractors');
  assert.ok(name, 'customer name not drawn');
  assert.ok(name.font.startsWith('700 '), `customer name should be bold, got: ${name.font}`);
});

await test('thermal layout shows the customer name in bold too', async () => {
  $('#fmt').value = 'thermal';
  fire($('#fmt'), 'change');
  assert.ok($('.sheet.thermal'));
  assert.equal($$('#sheet canvas').length, 0);
  assert.match(text(), /INVOICE/);
  assert.doesNotMatch(text(), /TAX INVOICE|GST|Taxable/);
  assert.ok($$('.sheet.thermal b').some((b) => b.textContent === 'Ramesh Contractors'));
  $('#fmt').value = 'a4';
  fire($('#fmt'), 'change');
  assert.equal($$('#sheet canvas.bill-page').length, 1);
});

await test('party ledger shows the invoice and running balance', async () => {
  await go(`#/party/${ramesh.id}`);
  assert.match(text(), /Opening balance/);
  assert.match(text(), /Invoice INV-0001/);
  assert.match($('.stat').textContent, /15,400\.00/); // 12,500 opening + 2,900 due
});

await test('receiving a payment from the ledger screen reduces the balance', async () => {
  $('#recv').click();
  await tick(100);
  const f = $('#modal #f');
  f.querySelector('[name=amount]').value = '2000';
  fire(f, 'submit');
  await tick(200);
  assert.equal((await db.get('parties', ramesh.id)).balance, openingBalance + 2900 - 2000);
  assert.match(text(), /Payment received/);
});

await test('billing screen shows no GST, just the total', async () => {
  await go('#/billing');
  $('#party').value = ramesh.id;
  fire($('#party'), 'change');
  assert.doesNotMatch($('#partyinfo').textContent, /GST/);
  const s = $('#isearch');
  s.value = 'hammer';
  fire(s, 'input');
  key(s, 'Enter');
  assert.match($('#totals').textContent, /Total/);
  assert.doesNotMatch($('#app').textContent, /GST|Taxable|HSN/i);
  $('#clear').click(); // confirm() is stubbed to true
  await tick(100);
  assert.equal($$('#cartrows tr[data-i]').length, 0);
});

await test('invoice list, settings and parties screens render', async () => {
  await go('#/invoices');
  assert.match(text(), /INV-0001/);
  await go('#/settings');
  assert.ok($('#f [name=shopName]'));
  assert.equal($('#f [name=gstin]'), null);
  assert.equal($('#f [name=state]'), null);
  assert.equal($('#f [name=taxInclusive]'), null);
  assert.doesNotMatch(text(), /GST/i);
  await go('#/parties');
  assert.match(text(), /Supreme Hardware Distributors/);
  await go('#/');
  assert.match(text(), /Sales today/);
  assert.doesNotMatch(text(), /New bill/, 'the extra New bill button is gone from the home screen');
  assert.doesNotMatch(text(), /sample/i === undefined ? '' : /ZZZ/);
  assert.equal($('#start-party'), null, 'first-time buttons go away once a bill exists');
  assert.equal($('#start-bill'), null);
});

await test('settings save and show on the invoice', async () => {
  await go('#/settings');
  const f = $('#f');
  f.querySelector('[name=shopName]').value = 'Shawear Test Hardware';
  fire(f, 'submit');
  await tick(150);
  assert.equal((await db.getSettings()).shopName, 'Shawear Test Hardware');
  const savedSettings = await db.get('meta', 'settings');
  assert.deepEqual(['gstin', 'state', 'taxInclusive'].filter((k) => k in savedSettings), []);
  const [inv] = await db.all('invoices');
  drawn.length = 0;
  await go(`#/invoice/${inv.id}`);
  assert.match(drawnText(), /Shawear Test Hardware/);
});

const shared = [];
Object.defineProperty(window.navigator, 'canShare', { configurable: true, value: (d) => !!(d && d.files && d.files.length) });
Object.defineProperty(window.navigator, 'share', { configurable: true, value: async (d) => { shared.push(d); } });

await test('Share on WhatsApp sends the bill as a picture file, not text', async () => {
  shared.length = 0;
  $('#wa').click();
  await tick(150);
  assert.equal(shared.length, 1);
  assert.equal(shared[0].text, undefined, 'no text message');
  assert.equal(shared[0].files.length, 1);
  assert.equal(shared[0].files[0].name, 'INV-0001.png');
  assert.equal(shared[0].files[0].type, 'image/png');
});

await test('PDF button shares a real PDF file', async () => {
  shared.length = 0;
  $('#pdf').click();
  await tick(150);
  assert.equal(shared.length, 1);
  const f = shared[0].files[0];
  assert.equal(f.name, 'INV-0001.pdf');
  assert.equal(f.type, 'application/pdf');
  const head = await f.slice(0, 8).text();
  assert.equal(head, '%PDF-1.4');
});

await test('cancelling an invoice restores stock and balance', async () => {
  const [inv] = await db.all('invoices');
  const balBefore = (await db.get('parties', ramesh.id)).balance;
  drawn.length = 0;
  $('#cancelinv').click();
  await tick(200);
  assert.equal((await db.get('invoices', inv.id)).status, 'cancelled');
  assert.equal((await db.get('items', cement.id)).stock, 120);
  assert.equal((await db.get('parties', ramesh.id)).balance, balBefore - 2900);
  assert.ok(drawn.some((d) => d.s === 'CANCELLED'), 'cancelled stamp should be drawn on the bill');
  assert.equal($('#cancelinv'), null);
});

await test('a walk-in bill is a plain invoice, with the name in bold on A4 and thermal', async () => {
  await db.put('items', {
    id: 'sand', name: 'River Sand', brand: '', code: 'SAND', unit: 'pcs', altUnits: [],
    prices: { retail: 500, contractor: 480, wholesale: 460 }, cost: 400, stock: 100, minStock: 0, createdAt: 1, updatedAt: 1,
  });
  await go('#/billing');
  const s = $('#isearch');
  s.value = 'sand';
  fire(s, 'input');
  key(s, 'Enter');
  assert.match($('#totals').textContent, /Total/);
  assert.doesNotMatch($('#partyinfo').textContent, /GST/);
  drawn.length = 0;
  $('#save').click();
  await tick(250);
  assert.match(window.location.hash, /^#\/invoice\//);
  const t = drawnText();
  assert.match(t, /Invoice no: INV-0002/);
  assert.doesNotMatch(t, /GST|HSN|Taxable|TAX INVOICE|Place of supply/);
  assert.match(t, /^INVOICE$/m);
  assert.ok(drawn.find((d) => d.s === 'Walk-in Customer').font.startsWith('700 '));
  $('#fmt').value = 'thermal';
  fire($('#fmt'), 'change');
  assert.doesNotMatch($('#sheet').textContent, /GST|Taxable|TAX INVOICE/);
  assert.match($('#sheet').textContent, /INVOICE/);
  assert.ok($$('.sheet.thermal b').some((b) => b.textContent === 'Walk-in Customer'));
});

console.log(`ui smoke: ${passed} passed`);
process.exit(0);
